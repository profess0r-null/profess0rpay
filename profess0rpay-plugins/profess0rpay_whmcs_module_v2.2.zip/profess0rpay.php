<?php
/* Profess0rPay WHMCS Plugin
 *
 * Copyright (c) 2025 Profess0rPay
 * Website: https://profess0rpay.com/
 * Developer: Siam
 * 
 */

/* 
How to use ?

Go to Module of your file - then go to gateway and upload file in root folder 
then again upload it on Callback file.

 */


if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function profess0rpay_MetaData()
{
    return array(
        'DisplayName' => 'Profess0rPay',
        'APIVersion' => '1.0',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}




function profess0rpay_link($params)
{
    $host_config = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $host_config = pathinfo($host_config, PATHINFO_FILENAME);

    if (isset($_POST['pay'])) {
        $response = profess0rpay_payment_url($params);
        $response = json_decode($response);
        if (isset($response->status) && $response->status) {
            return '<form action="' . $response->payment_url . '" method="GET">
            <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
            </form>';
        }

        return $response->message;
    }


    if ($host_config == "viewinvoice") {
        return '<form action="" method="POST">
        <input class="btn btn-primary" name="pay" type="submit" value="' . $params['langpaynow'] . '" />
        </form>';
    } else {
        $response = profess0rpay_payment_url($params);
        $response = json_decode($response);

        if (isset($response->status) && $response->status) {
            return '<form action="' . $response->payment_url . '" method="GET">
            <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
            </form>';
        }

        return $response->message;
    }
}


function profess0rpay_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Profess0rPay',
        ),
        'apiBaseUrl' => array(
            'FriendlyName' => 'Gateway API URL',
            'Type' => 'text',
            'Size' => '150',
            'Default' => 'https://your-domain.com/api/v1/',
            'Description' => 'Enter Your Profess0rPay Base API URL',
        ),
        'apiKey' => array(
            'FriendlyName' => 'Brand API Key',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Profess0rPay Brand API Key',
        ),
        'currency_rate' => array(
            'FriendlyName' => 'Currency Rate',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '120',
            'Description' => 'Enter Dollar to BDT Rate',
        )
    );
}

function profess0rpay_payment_url($params)
{
    $cus_name = $params['clientdetails']['firstname'] . " " . $params['clientdetails']['lastname'];
    $cus_email = $params['clientdetails']['email'];

    $apiBaseUrl = rtrim($params['apiBaseUrl'], '/');
    $apiKey = $params['apiKey'];
    $currency_rate = $params['currency_rate'];
    $invoiceId = $params['invoiceid'];

    if ($params['currency'] == "USD") {
        $amount = $params['amount'] * $currency_rate;
    } else {
        $amount = $params['amount'];
    }

    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        $url = "https://";
    } else {
        $url = "http://";
    }
    $url .= $_SERVER['HTTP_HOST'];
    $systemUrl = $url;

    $redirect_url = $systemUrl . '/viewinvoice.php?id=' . $invoiceId;
    $cancel_url = $systemUrl . '/viewinvoice.php?id=' . $invoiceId;
    $webhook_url = $systemUrl . '/modules/gateways/callback/profess0rpay.php?api=' . $apiKey . '&invoice=' . $invoiceId;

    $data = array(
        "cus_name" => $cus_name,
        "cus_email" => $cus_email,
        "amount" => (string) $amount,
        "redirect_url" => $redirect_url,
        "cancel_url" => $cancel_url,
        "webhook_url" => $webhook_url,
        "metadata" => array(
            "invoiceId" => $invoiceId,
        ),
    );

    $headers = array(
        'Content-Type: application/json',
        'zini-api-key: ' . $apiKey,
    );

    $apiUrl = $apiBaseUrl . '/payment/create';

    $curl = curl_init();
    $data = json_encode($data);

    curl_setopt_array($curl, array(
        CURLOPT_URL => $apiUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => $headers,
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    return $response;
}
