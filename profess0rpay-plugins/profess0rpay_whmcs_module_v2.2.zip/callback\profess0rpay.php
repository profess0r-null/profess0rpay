<?php
/* Profess0rPay WHMCS Gateway Callback
 *
 * Copyright (c) 2025 Profess0rPay
 * Website: https://profess0rpay.com
 * Developer: Siam
 */

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

use WHMCS\Config\Setting;

$whmcsInvoice = $_REQUEST['invoice'] ?? '';
$invoiceId = $_REQUEST['invoice_id'] ?? '';
$transactionId = $_REQUEST['transactionId'] ?? '';
$paymentAmount = $_REQUEST['paymentAmount'] ?? '';
$paymentFee = $_REQUEST['paymentFee'] ?? 0;
$gatewayModuleName = "profess0rpay";

$apiKey = $_GET['api'] ?? '';

$gatewayParams = getGatewayVariables($gatewayModuleName);
if (!$gatewayParams["type"]) {
    die("Module Not Activated");
}
$apiBaseUrl = rtrim($gatewayParams['apiBaseUrl'], '/');

// Verify payment using Profess0rPay API
$verifyData = array(
    "invoiceId" => $invoiceId,
);

$headers = array(
    'Content-Type: application/json',
    'zini-api-key: ' . $apiKey,
);

$apiUrl = $apiBaseUrl . '/payment/verify';

$curl = curl_init();
$verifyData = json_encode($verifyData);

curl_setopt_array($curl, array(
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => $verifyData,
    CURLOPT_HTTPHEADER => $headers,
));

$response = curl_exec($curl);
curl_close($curl);

$data = json_decode($response, true);

if (isset($data['status']) && $data['status'] === 'COMPLETED') {
    $metadataInvoiceId = $data['metadata']['invoiceId'];

    $transactionId = $data['transaction_id'] ?? $invoiceId;
    $paymentAmount = $data['amount'] ?? $paymentAmount;

    $cbInvoiceId = checkCbInvoiceID($metadataInvoiceId, $gatewayModuleName);
    checkCbTransID($transactionId);
    logTransaction($gatewayModuleName, $data, "Verified Payment");

    addInvoicePayment(
        $cbInvoiceId,
        $transactionId,
        $paymentAmount,
        $paymentFee,
        $gatewayModuleName
    );

    $systemUrl = Setting::getValue('SystemURL');
    ?>
    <script>
        location.href = "<?php echo $systemUrl . '/viewinvoice.php?id=' . $cbInvoiceId; ?>";
    </script>
    <?php
} else {
    echo "Payment verification failed. Please contact support.";
}
?>