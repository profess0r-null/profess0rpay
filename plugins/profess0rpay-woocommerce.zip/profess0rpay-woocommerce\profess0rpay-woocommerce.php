<?php
/*
 * Plugin Name: Profess0rPay WooCommerce Gateway
 * Plugin URI: https://github.com/profess0r-null/profess0rpay
 * Description: Accept bKash, Nagad, Rocket, and other payments using the self-hosted Profess0rPay gateway.
 * Author: Profess0r-Null
 * Author URI: https://github.com/profess0r-null
 * Version: 1.0.0
 * Text Domain: profess0rpay
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Ensure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    return;
}

add_action( 'plugins_loaded', 'profess0rpay_init_gateway_class' );

function profess0rpay_init_gateway_class() {

    class WC_Gateway_Profess0rPay extends WC_Payment_Gateway {

        public function __construct() {
            $this->id                 = 'profess0rpay';
            $this->icon               = plugin_dir_url( __FILE__ ) . 'default_favicon.png'; // Add a gateway icon URL if needed
            $this->has_fields         = false;
            $this->method_title       = 'Profess0rPay';
            $this->method_description = 'Accept Mobile Financial Services (bKash, Nagad, etc.) directly.';

            // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Define user set variables
            $this->title        = $this->get_option( 'title' );
            $this->description  = $this->get_option( 'description' );
            $this->api_key      = $this->get_option( 'api_key' );
            $this->gateway_url  = rtrim($this->get_option( 'gateway_url' ), '/');

            // Save settings
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            
            // Webhook Hook
            add_action( 'woocommerce_api_profess0rpay_webhook', array( $this, 'webhook_listener' ) );
            
            // Fix Icon Size on Checkout Page
            add_action( 'wp_head', array( $this, 'fix_icon_size' ) );
        }

        public function fix_icon_size() {
            echo '<style>.wc_payment_method.payment_method_profess0rpay img { max-width: 150px !important; max-height: 40px !important; object-fit: contain; }</style>';
        }

        /**
         * Gateway Settings Form Fields.
         */
        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title'   => 'Enable/Disable',
                    'type'    => 'checkbox',
                    'label'   => 'Enable Profess0rPay Gateway',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title'       => 'Title',
                    'type'        => 'text',
                    'description' => 'This controls the title which the user sees during checkout.',
                    'default'     => 'Mobile Banking (bKash, Nagad)',
                    'desc_tip'    => true,
                ),
                'description' => array(
                    'title'       => 'Description',
                    'type'        => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default'     => 'Pay securely via bKash, Nagad, Rocket, etc.',
                ),
                'gateway_url' => array(
                    'title'       => 'Gateway URL',
                    'type'        => 'text',
                    'description' => 'Your Profess0rPay installation domain without https:// (e.g., pay.yourdomain.com)',
                    'default'     => '',
                    'desc_tip'    => true,
                ),
                'api_key' => array(
                    'title'       => 'Store API Key',
                    'type'        => 'password',
                    'description' => 'Your unique Store API Key from the Profess0rPay dashboard.',
                    'default'     => '',
                ),
                'disable_ssl_verify' => array(
                    'title'   => 'Disable SSL Verification',
                    'type'    => 'checkbox',
                    'label'   => 'Disable (Check this if your gateway lacks a valid SSL certificate)',
                    'default' => 'no'
                )
            );
        }

        /**
         * Process the payment and return the result.
         */
        public function process_payment( $order_id ) {
            $order = wc_get_order( $order_id );

            if ( empty( $this->api_key ) || empty( $this->gateway_url ) ) {
                wc_add_notice( 'Payment Error: Gateway is not configured properly.', 'error' );
                return;
            }

            // Prepare Payload
            $payload = array(
                'full_name'      => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'email_address'  => $order->get_billing_email(),
                'mobile_number'  => $order->get_billing_phone(),
                'amount'         => (float) $order->get_total(),
                'currency'       => get_woocommerce_currency(),
                'return_url'     => $this->get_return_url( $order ),
                'webhook_url'    => add_query_arg( 'wc-api', 'profess0rpay_webhook', home_url( '/' ) ),
                'metadata'       => json_encode( array( 'order_id' => $order_id ) )
            );

            $gateway_domain = trim( $this->gateway_url );
            $gateway_domain = rtrim( $gateway_domain, '/' );
            $gateway_domain = preg_replace( '#^https?://#', '', $gateway_domain );
            $scheme = ( strpos( $gateway_domain, 'localhost' ) !== false ) ? 'http://' : 'https://';
            
            $endpoint = $scheme . $gateway_domain . '/api/create-payment';
            $ssl_verify = $this->get_option('disable_ssl_verify') === 'yes' ? false : true;

            $args = array(
                'method'      => 'POST',
                'timeout'     => 30,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking'    => true,
                'headers'     => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $this->api_key,
                ),
                'body'        => json_encode( $payload ),
                'sslverify'   => $ssl_verify,
            );

            $response = wp_remote_post( $endpoint, $args );

            if ( is_wp_error( $response ) ) {
                wc_add_notice( 'Connection Error: ' . $response->get_error_message(), 'error' );
                return;
            }

            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );

            if ( !empty( $data['pp_url'] ) ) {
                
                // Remove cart
                WC()->cart->empty_cart();

                // Return redirect string
                return array(
                    'result'   => 'success',
                    'redirect' => $data['pp_url']
                );
            } else {
                $error_msg = 'Unknown error from gateway.';
                if (is_array($data)) {
                    if (isset($data['message'])) {
                        $error_msg = $data['message'];
                    } elseif (isset($data['error']['message'])) {
                        $error_msg = $data['error']['message'];
                    } else {
                        $error_msg = 'Unknown JSON format. Dump: ' . json_encode($data);
                    }
                } else {
                    $error_msg = 'Invalid response from gateway. Endpoint: ' . $endpoint . ' | Raw Response: ' . substr($body, 0, 100);
                }
                wc_add_notice( 'Gateway Error: ' . $error_msg, 'error' );
                return;
            }
        }

        /**
         * Listen for Webhook requests from Profess0rPay.
         */
        public function webhook_listener() {
            $raw_payload = file_get_contents( 'php://input' );
            $data = json_decode( $raw_payload, true );

            if ( ! $data || ! isset( $data['pp_id'] ) ) {
                http_response_code( 400 );
                die( 'Bad Request' );
            }

            $pp_id = sanitize_text_field( $data['pp_id'] );

            // Double Verify the Payment for Security
            $endpoint = $this->gateway_url . '/api/verify-payment';
            $ssl_verify = $this->get_option('disable_ssl_verify') === 'yes' ? false : true;

            $args = array(
                'method'      => 'POST',
                'timeout'     => 30,
                'headers'     => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $this->api_key,
                ),
                'body'        => json_encode( array( 'pp_id' => $pp_id ) ),
                'sslverify'   => $ssl_verify,
            );

            $response = wp_remote_post( $endpoint, $args );

            if ( is_wp_error( $response ) ) {
                http_response_code( 500 );
                die( 'Verification connection failed' );
            }

            $body = wp_remote_retrieve_body( $response );
            $verify_data = json_decode( $body, true );

            // Security Checks
            if ( isset( $verify_data['status'] ) && $verify_data['status'] === 'completed' ) {
                
                $meta = $verify_data['metadata'];
                if (is_string($meta)) {
                    $meta = json_decode($meta, true);
                }
                
                $order_id = $meta['order_id'] ?? 0;
                $order = wc_get_order( $order_id );

                if ( ! $order ) {
                    http_response_code( 404 );
                    die( 'Order not found' );
                }

                // Duplicate payment protection
                if ( $order->is_paid() || $order->has_status( 'completed' ) || $order->has_status( 'processing' ) ) {
                    http_response_code( 200 );
                    die( 'Order already processed' );
                }

                // Amount Verification
                $api_amount = (float) $verify_data['amount'];
                $order_amount = (float) $order->get_total();

                if ( abs($api_amount - $order_amount) > 0.01 ) {
                    $order->update_status( 'on-hold', 'Payment received but amount mismatch. Expected: ' . $order_amount . ' Received: ' . $api_amount );
                    http_response_code( 200 );
                    die( 'Amount mismatch recorded' );
                }

                // Payment Success!
                $transaction_id = isset( $verify_data['transaction_id'] ) ? $verify_data['transaction_id'] : '';
                $gateway_name   = isset( $verify_data['gateway'] ) ? $verify_data['gateway'] : 'Profess0rPay';
                
                $order->payment_complete( $transaction_id );
                $order->add_order_note( "Payment completed via $gateway_name. TrxID: $transaction_id" );
                
                http_response_code( 200 );
                die( 'Webhook Processed Successfully' );
            }

            http_response_code( 400 );
            die( 'Payment not verified or not completed' );
        }
    }
}

// Register Gateway
add_filter( 'woocommerce_payment_gateways', 'profess0rpay_add_gateway_class' );
function profess0rpay_add_gateway_class( $gateways ) {
    $gateways[] = 'WC_Gateway_Profess0rPay';
    return $gateways;
}
